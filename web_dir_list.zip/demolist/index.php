<?php
include 'db.php';

// Set the number of items per page
$limit = 2;

// Get the current page number
$page = isset($_GET['page']) ? $_GET['page'] : 1;
$start = ($page - 1) * $limit;

// Get the search query
$search = isset($_GET['search']) ? $_GET['search'] : '';

// Get total records
$sql_count = "SELECT COUNT(*) FROM entries WHERE title LIKE '%$search%'";
$result_count = $conn->query($sql_count);
$total = $result_count->fetch_row()[0];

// Calculate total pages
$pages = ceil($total / $limit);

// Fetch the data
$sql = "SELECT * FROM entries WHERE title LIKE '%$search%' LIMIT $start, $limit";
$result = $conn->query($sql);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Pagination with Search</title>
    <style>
        table {
            width: 100%;
            border-collapse: collapse;
        }
        table, th, td {
            border: 1px solid black;
        }
        th, td {
            padding: 8px;
            text-align: left;
        }
        .pagination {
            margin: 10px 0;
        }
        .pagination a {
            margin: 0 5px;
            padding: 5px 10px;
            text-decoration: none;
            border: 1px solid #ddd;
        }
        .pagination a.active {
            background-color: #007BFF;
            color: white;
            border: 1px solid #007BFF;
        }
        .pagination a:hover {
            background-color: #ddd;
        }
    </style>
</head>
<body>

<h2>Pagination with Search</h2>

<form method="GET" action="">
    <input type="text" name="search" value="<?php echo $search; ?>" placeholder="Search...">
    <input type="submit" value="Search">
</form>

<table>
    <tr>
        <th>ID</th>
        <th>Name</th>
        <th>Other Columns...</th>
    </tr>
    <?php while($row = $result->fetch_assoc()): ?>
        <tr>
            <td><?php echo $row['id']; ?></td>
            <td><?php echo $row['title']; ?></td>
            <td><?php echo $row['short_des']; ?></td>
        </tr>
    <?php endwhile; ?>
</table>

<div class="pagination">
    <?php for($i = 1; $i <= $pages; $i++): ?>
        <a href="?page=<?php echo $i; ?>&search=<?php echo $search; ?>" class="<?php if($page == $i) echo 'active'; ?>"><?php echo $i; ?></a>
    <?php endfor; ?>
</div>

</body>
</html>

<?php
$conn->close();
?>
